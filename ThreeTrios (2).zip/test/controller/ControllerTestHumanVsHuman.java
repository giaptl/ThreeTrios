package controller;


import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import model.MockThreeTriosModel;
import player.HumanPlayer;
import player.IPlayer;
import view.IGameView;
import view.MockGameView;
/**
 * Test class for the controller. Yet to be implemented due to time constraints.
 */
public class ControllerTestHumanVsHuman {
  private Controller controller1;
  private Controller controller2;
  private MockThreeTriosModel mockModel;
  private IPlayer player1;
  private IPlayer player2;
  private IGameView mockView1;
  private IGameView mockView2;

  @Before
  public void setUp() {
    mockModel = new MockThreeTriosModel();
    player1 = new HumanPlayer("Bob", new ArrayList<>());
    player2 = new HumanPlayer("Sarah", new ArrayList<>());
    mockView1 = new MockGameView();
    mockView2 = new MockGameView();
    controller1 = new Controller(mockModel, player1, mockView1);
    controller2 = new Controller(mockModel, player2, mockView2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testControllerHandlesNullModel() {
   new Controller(null, player1, mockView1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testControllerHandlesNullPlayer() {
    new Controller(mockModel, null, mockView1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testControllerHandlesNullView() {
    new Controller(mockModel, player1, null);
  }

  @Test
  public void testGameProgression() {

  }


//  @Test
//  public void testOnCardSelected() {
//    mockModel.setCurrentPlayer(player);
//    mockModel.addCardToPlayerHand(player, testCard);
//
//    controller.onCardSelected(player, 0);
//
//    assertEquals(player, mockView.getLastUpdatedPlayer());
//    assertEquals(testCard, mockView.getLastUpdatedCard());
//  }

//  @Test
//  public void testOnGridCellSelected() {
//    mockModel.setCurrentPlayer(player1);
//
//    controller1.onCardSelected(player1, 0);
//    controller1.onGridCellSelected(0, 0);
//
//    assertTrue(mockModel.isCardPlayed(testCard, 0, 0));
//    assertNull(mockView1.getLastUpdatedCard());
//  }
//
//  @Test
//  public void testGameOver() {
//    mockModel.setGameOver(true);
//    mockModel.setWinner(player);
//    mockModel.setPlayerScore(player, 10);
//
//    controller.gameOver(player);
//
//    assertEquals(player, view.getLastWinner());
//    assertEquals(10, view.getLastWinningScore());
//  }


}