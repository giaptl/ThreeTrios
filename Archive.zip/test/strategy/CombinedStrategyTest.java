package strategy;

public class CombinedStrategyTest {

//  @Test
//  public void testCombinedStrategyProgression() {
//    for (int i = 0; i < 5; i++) {
//      assertEquals(redPlayer, mockModel.getCurrentPlayer());
//      Move redMove = combinedStrategy.selectMove(redPlayer, mockModel);
//      assertNotNull(redMove);
//      if (i < 4) {
//        assertTrue(isCornerMove(redMove));
//      } else {
//        assertTrue(isFlipMaximizingMove(redMove));
//      }
//      mockModel.playCard(redPlayer, redMove.getCard(), redMove.getRow(), redMove.getCol());
//      assertFalse(mockModel.getPlayerHand(redPlayer).contains(redMove.getCard()));
//      assertEquals(bluePlayer, mockModel.getCurrentPlayer());
//
//      // Simulate blue player's move
//      Card blueCard = mockModel.getPlayerHand(bluePlayer).get(0);
//      mockModel.playCard(bluePlayer, blueCard, 1, 1);
//      assertEquals(redPlayer, mockModel.getCurrentPlayer());
//    }
//  }
}
